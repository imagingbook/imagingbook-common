/*******************************************************************************
 * This software is provided as a supplement to the authors' textbooks on digital
 *  image processing published by Springer-Verlag in various languages and editions.
 * Permission to use and distribute this software is granted under the BSD 2-Clause 
 * "Simplified" License (see http://opensource.org/licenses/BSD-2-Clause). 
 * Copyright (c) 2006-2016 Wilhelm Burger, Mark J. Burge. All rights reserved. 
 * Visit http://imagingbook.com for additional details.
 *******************************************************************************/

package imagingbook.pub.geometry.mappings.linear;

/**
 * This class represents a 2D shear transformation (as a special case of 
 * affine transformation).
 */
public class Shear extends AffineMapping {
	
	/**
	 * Creates a null shear (identity) transformation.
	 */
	public Shear() {
		super();
	}

	/**
	 * Creates a shear transform.
	 * @param bx shear factor in x-direction
	 * @param by shear factor in y-direction
	 */
	public Shear(double bx, double by) {
		super( // calls constructor of AffineMapping
			1,  bx, 0,
			by, 1,  0);
	}
	
	public Shear(Shear sh) {
		super(sh);
	}
	
	/**
	 * {@inheritDoc}
	 * @return a new shear mapping
	 */
	public Shear duplicate() {
		return new Shear(this);
	}
	
}


